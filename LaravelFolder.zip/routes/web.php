<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MahasiswaController;

/*
|--------------------------------------------------------------------------
| HOME
|--------------------------------------------------------------------------
*/
Route::get('/home', function () {
    return view('home');
});

/*
|--------------------------------------------------------------------------
| DEFAULT
|--------------------------------------------------------------------------
*/
Route::get('/', function () {
    return redirect('/home');
});

/*
|--------------------------------------------------------------------------
| MAHASISWA (CRUD)
|--------------------------------------------------------------------------
*/
Route::get('/mahasiswa', [MahasiswaController::class, 'index']);
Route::get('/mahasiswa/tambah', [MahasiswaController::class, 'tambahmahasiswa']);
Route::post('/mahasiswa/simpan', [MahasiswaController::class, 'insertdata']);

Route::get('/mahasiswa/edit/{id}', [MahasiswaController::class, 'tampildata']);
Route::post('/mahasiswa/{id}/edit', [MahasiswaController::class, 'editdata']);

Route::post('/mahasiswa/{id}/delete', [MahasiswaController::class, 'delete']);
