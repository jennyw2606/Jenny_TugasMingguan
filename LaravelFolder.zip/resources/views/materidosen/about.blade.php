@extends('materidosen.layouts.main')

@section('content')
    <h1>Tentang Kami</h1>
    <p>Halaman ini berisi informasi tentang dosen dan kegiatan akademik.</p>
    <p>Website ini dibuat untuk latihan Laravel sesuai materi perkuliahan.</p>
@endsection