@extends('materidosen.layouts.main')

@section('content')
    <h1>Profil Dosen</h1>
    <p>Nama: Jenny Wulandari</p>
    <p>Bidang: Pemrograman Web</p>
    <p>Email: jennywulandari2606@gmail.com</p>
@endsection