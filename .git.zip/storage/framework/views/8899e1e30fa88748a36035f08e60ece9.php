<?php $__env->startSection('title', $berita->judul); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto py-5">
    <h2 class="text-3xl font-bold mb-4"><?php echo e($berita->judul); ?></h2>
    <p class="text-gray-500 mb-2">Ditulis oleh: <?php echo e($berita->penulis ?? 'Admin'); ?> | <?php echo e($berita->tanggal ?? date('d M Y')); ?></p>
    
    <?php if($berita->gambar): ?>
        <img src="<?php echo e(asset('storage/' . $berita->gambar)); ?>" alt="<?php echo e($berita->judul); ?>" class="rounded-lg shadow mb-4 w-full max-h-[400px] object-cover">
    <?php endif; ?>

    <div class="text-lg leading-relaxed">
        <?php echo nl2br(e($berita->konten)); ?>

    </div>

    <a href="<?php echo e(route('berita.index')); ?>" class="inline-block mt-6 text-blue-600 hover:underline">← Kembali ke daftar berita</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\laravel\resources\views/materidosen/singleberita.blade.php ENDPATH**/ ?>