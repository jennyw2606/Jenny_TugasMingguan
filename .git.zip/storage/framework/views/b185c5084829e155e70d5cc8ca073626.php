<?php $__env->startSection('title', 'Tambah Data Mahasiswa'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4">

    <h3 class="mb-3">Tambah Data Mahasiswa</h3>

    
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="card shadow-sm">
        <div class="card-body">
            <form action="/mahasiswa/simpan" method="POST">
                <?php echo csrf_field(); ?>

                <div class="mb-3">
                    <label class="form-label">Nama</label>
                    <input type="text"
                           name="name"
                           value="<?php echo e(old('name')); ?>"
                           class="form-control"
                           required>
                </div>

                <div class="mb-3">
                    <label class="form-label">NIM</label>
                    <input type="number"
                           name="nim"
                           value="<?php echo e(old('nim')); ?>"
                           class="form-control"
                           required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Program Studi</label>
                    <input type="text"
                           name="prodi"
                           value="<?php echo e(old('prodi')); ?>"
                           class="form-control"
                           required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="email"
                           name="email"
                           value="<?php echo e(old('email')); ?>"
                           class="form-control"
                           required>
                </div>

                <div class="mb-3">
                    <label class="form-label">No HP</label>
                    <input type="text"
                           name="nohp"
                           value="<?php echo e(old('nohp')); ?>"
                           class="form-control"
                           required>
                </div>

                <button type="submit" class="btn btn-primary">
                    Simpan Data
                </button>

                <a href="/mahasiswa" class="btn btn-secondary ms-2">
                    Kembali
                </a>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\laravel\resources\views/tambahmahasiswa.blade.php ENDPATH**/ ?>